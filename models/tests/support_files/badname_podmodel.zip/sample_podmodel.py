# This import you need
from models.podtk_model import PODModel
# Everything else depends on what your model requires
import numpy as np
import time

# All POD Models must be a subclass of PODModel
class AHatVsA(PODModel):

    # All POD Models must define the following information fields.
    name = "A hat vs. A"
    description = "Your description here"
    authors = "TRI/Austin, Inc. and Computational Tools, Inc."
    version = "1.0"
    url = "www.nditoolbox.com"
    copyright = ""
    
    
    def __init__(self):
        PODModel.__init__(self, self.name, self.description, self.inputdata, self.params, self.settings)

    def run(self):
        """Executes the POD Model"""
        
        # Example busy work
        print("Input Data Configuration:")
        for key, value in self.inputdata.iteritems():
            print("\t{0}={1}".format(key, value))
        print("\nParameters Configuration:")
        for key, value in self.params.iteritems():
            print("\t{0}={1}".format(key, value))
        print("\nSettings Configuration:")
        for key, value in self.settings.iteritems():
            print("\t{0}={1}".format(key, value))
        print("\n")
        for i in range(5):
            msg = "*"*i
            print(msg)
            time.sleep(1)
            
        # To display tabular data after execution, set self._data to your output data
        # POD Toolkit will load the NumPy array and display it automatically.
        # You can safely ignore this if you don't need to display data.
        self._data = np.array([np.arange(0., 5., 0.2), np.arange(0., 5., 0.2)])
        
        # To display a text summary after execution, set self.results
        # POD Toolkit will display this text in the text output field automatically.
        # You can safely ignore this if you don't need to display a text summary.
        self.results = "Sample POD Model completed successfully."
        
    def plot1(self, axes_hdl):
        """Generates the primary plot on the specified matplotlib Axes instance."""
        
        # Example of plotting - if you have no primary plot, no need to define a plot1 method.
        axes_hdl.plot([1,2,3,4], [1,4,9,16], 'ro')
        axes_hdl.axis([0, 6, 0, 20])
        axes_hdl.set_title("Example Plot 1")
        axes_hdl.set_xlabel("X Axis")
        axes_hdl.set_ylabel("Y Axis")

    def plot2(self, axes_hdl):
        """Generates the secondary plot on the specified matplotlib Axes instance."""
        
        # Example of plotting - if you have no secondary plot, no need to define a plot2 method.
        t = np.arange(0., 5., 0.2)
        axes_hdl.plot(t, t, 'r--', t, t**2, 'bs', t, t**3, 'g^')
        axes_hdl.set_title("Example Plot 1")
        axes_hdl.set_xlabel("X Axis")
        axes_hdl.set_ylabel("Y Axis")
        axes_hdl.legend(("Linear", "Square", "Cubic"), 'upper right', title="Functions", shadow=True, fancybox=True)