medfilter - simple median filtration filter
Chris R. Coughlin (TRI/Austin, Inc.)

Copyright (C) 2012 TRI/Austin, Inc.  All rights reserved.